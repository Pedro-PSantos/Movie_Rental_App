﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MVC_IMDb.Forms
{
    public partial class FormMoviesList : Form
    {
        public FormMoviesList()
        {
            InitializeComponent();
        }

        private void btnEncerrar_Click(object sender, EventArgs e)
        {

        }
    }
}
