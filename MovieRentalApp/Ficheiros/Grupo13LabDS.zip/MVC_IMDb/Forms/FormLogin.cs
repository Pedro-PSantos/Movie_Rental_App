using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MVC_IMDb.Views;

namespace MVC_IMDb.Forms
{
    public partial class FormLogin : Form
    {
        // View associada ao form de login
        private LoginView view;
        public FormLogin(LoginView _view)
        {
            InitializeComponent();

            // Fixa o form no centro do ecr�
            StartPosition = FormStartPosition.CenterScreen;

            // Guarda uma refer�ncia � view de login para lhe poder informar quando o utilizador carrega no bot�o de login
            view = _view;
        }

        // Ocorre quando o utilizador carrega no bot�o de login do form
        private void loginButton_Click(object sender, EventArgs e)
        {
            // Testa se as credenciais foram preenchidas
            if (string.IsNullOrEmpty(_utilizadorTextBox.Text) || string.IsNullOrEmpty(_passwordTextBox.Text))
            {
                MessageBox.Show("Por favor preencha as credenciais.");
                return;
            }

            // Informa a view que o utilizador carregou no bot�o de login, para a view poder informar o controller
            view.CliqueEmFazerLogin(sender, _utilizadorTextBox.Text, _passwordTextBox.Text);
        }
        private void btnEncerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}