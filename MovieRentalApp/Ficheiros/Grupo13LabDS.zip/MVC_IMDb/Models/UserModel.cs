﻿using System.ComponentModel;

namespace MVC_IMDb.Models
{
    public class UserModel
    {
        // Credenciais do utilizador
        public string Username { get; set; }
        public string Password { get; set; }

        // Serve para notificar a view que o estado de login foi alterado
        public event PropertyChangedEventHandler? EstadoDeLoginAlterado;

        // Estado de login, inicializa-se a falso
        private bool FezLogin;

        // Serve para alterar o estado de login sob o padrão de design Observer
        private bool EstadoLogin
        {
            set
            {
                FezLogin = value;
                MudarEstadoDeAutenticacao("FezLogin"); // Informa a view do novo estado de login
            }
        }

        public UserModel()
        {
            Username = string.Empty;
            Password = string.Empty;
            FezLogin = false;
        }

        public void Autenticar(string _username, string _password)
        {

            EstadoLogin = true;

            /* TODO
             * 
             ** Chamar a api do facebook
             ** Validar login
             * 
             *
             * string AppId = "2505158666300184";
             * string AppSecret = "be293c156b308084f938fb6d950ee655";
             * 
             */
        }
        // Informa a view que o estado de login mudou
        protected void MudarEstadoDeAutenticacao(string propertyName)
        {
            EstadoDeLoginAlterado?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        // Usado para a view poder obter o estado de login
        public bool GetEstadoLogin()
        {
            return FezLogin;
        }
    }
}