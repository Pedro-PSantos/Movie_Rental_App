using MVC_IMDb.Controllers;
using System;

namespace MVC_IMDb
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // O programa inicializa no login
            new LoginController().IniciarLogin();

            // O resto do programa ocorre ap�s login
            new MenuController().IniciarPrograma();
        }
    }
}