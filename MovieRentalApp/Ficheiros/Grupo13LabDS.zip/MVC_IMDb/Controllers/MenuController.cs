﻿using MVC_IMDb.Models;
using MVC_IMDb.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVC_IMDb.Controllers
{
    public class MenuController
    {
        private MovieModel model;
        private MenuView view;
        public MenuController()
        {
            model = new MovieModel();
            view = new MenuView(model);
        }
        public void IniciarPrograma()
        {
            view.FormDeMenu();
            
            /* TODO
             *
             * Fazer assign dos eventos da view quando as chamadas à api estiverem implementadas
             */

            //view.EventoDeListarFilmes += 
            //view.EventoDeRequisitarFilmes +=
        }
    }
}
