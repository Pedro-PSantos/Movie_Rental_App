using System.Net.Http;
using System.Threading.Tasks;

public class MovieSearchApiClient
{
    //private readonly HttpClient _httpClient;
    //private readonly string _apiKey;

    //public MovieSearchApiClient(HttpClient httpClient, string apiKey)
    //{
    //    HttpClient = httpClient;
    //    ApiKey = apiKey;
    //    //API KEY disponível: a8ec58e252045db51dda98b6f5db8821
    //}

    //public async Task<string> SearchMovieAsync(string movieTitle)
    //{
    //    var url = $"http://api.themoviedb.org/3/search/movie?api_key={ApiKey}&query={movieTitle}";
    //    var response = await HttpClient.GetAsync(url);
    //    var content = await response.Content.ReadAsStringAsync();
    //    return content;
    //}
}
